
const express = require("express");
const req = require("express/lib/request");
const app = express();
const mongoose = require("mongoose");
app.use(express.json());
mongoose.connect("mongodb://localhost:27017/mydb",{
    useNewUrlParser:true,
    useUnifiedTopology:true,
},(err)=>{
    if(!err){
        console.log("connected to db")
    }
    else{
        console.log("not connected")
    }
})

app.listen(5000,()=>{
    console.log("on port 5000")
})

//shema
const sch={
    Name:String,
    Post:String,
    DOB:String,
    Phone:Number,
    Email:String,
    id:Number
}
const monmodel=mongoose.model("newcol",sch);

//post
app.post("/post",async(req,res)=>{
    console.log("inside post fuction");

    const data=new monmodel({
        Name:req.body.Name,
        Post:req.body.Post,
        DOB:req.body.DOB,
        Phone:req.body.Phone,
        Email:req.body.Email,
        id:req.body.id
    });
    const val=await data.save();
    res.send("posted");
})

//put

app.put("/update/:id",async(req,res)=>{
    let upid=req.params.id;
    let upName=req.body.Name;
    let upPost=req.body.Post;
    let upDOB=req.body.DOB;
    let upPhone=req.body.Phone;
    let upEmail=req.body.Email;


    monmodel.findByIdAndUpdate({id:upid},{$set:{Name:upName,Post:upPost,DOB:upDOB,Phone:upPhone,Email:upEmail}},
        {new:true},(error,data)=>{
            if(err){
                res.send("error")
            }
    
         else{

            if(data==null){
                res.send("nothing found")
            }
            else{
                res.send(data)
            }
        }

    })

})
//delete by id 


app.delete('/del/:id',function(req,res){
    let delid=req.params.id;
    monmodel.findByIdAndDelete(({id:delid}),function(err,docs){
        if(error){
            res.send("errorrrr")
        }
        else{

        if(docs==null){
            res.send("wrong id ")
        }else{
            res.send(docs);
        }
        res.send(docs);
    }
    })
})